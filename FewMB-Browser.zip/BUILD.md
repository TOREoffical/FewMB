# FewMB Browser - Build Instructions

## Quick Start (Windows with MinGW)

```bash
# Navigate to project directory
cd FewMB-Browser

# Create build directory
mkdir build
cd build

# Configure with CMake
cmake .. -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release

# Build
mingw32-make -j4

# Run
./bin/FewMB.exe
```

## Dependencies

### Windows
- MinGW-w64 (G++ compiler)
- CMake 3.15+
- zlib (for compression)

### Linux
```bash
sudo apt-get install cmake g++ zlib1g-dev
```

### macOS
```bash
brew install cmake zlib
```

## Project Structure

```
FewMB-Browser/
├── src/
│   ├── core/          # Browser engine, tab management, compression
│   ├── ui/            # Windows, tabs, controls
│   ├── features/     # 500+ features
│   ├── network/      # HTTP, DNS cache, connections
│   ├── extensions/   # Chrome extension adapter
│   └── utils/        # Logging, config, compression
├── build/             # Build output
└── .github/           # CI/CD workflows
```

## Features

### Memory Optimization
- Tab compression reduces RAM usage to ~1MB per tab
- Color deduplication eliminates duplicate color downloads
- Resource caching prevents re-downloading

### Built-in Features (500+)
- Password Manager
- Translator
- AI Assistant (FewMB)
- Bookmarks
- Download Manager
- History
- MCP Tools Client
- Chrome Extension Support

## GitHub Actions

The project includes automatic builds for:
- Windows (MinGW)
- Linux (GCC)
- macOS (Clang)

Releases are created automatically when a version tag is pushed.