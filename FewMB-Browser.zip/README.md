# FewMB Browser

> Ultra-lightweight, full-featured web browser with AI integration

## Features

- **~10-50MB EXE** - Minimal file size (depends on WebView2 runtime)
- **WebView2 Engine** - Chromium-based rendering
- **Low RAM Usage** - Optimized tab management
- **AI Assistant** - Built-in FewMB assistant (click the star button)
- **500+ Features**:
  - Password Manager
  - Bookmarks with folders
  - Download Manager
  - History with search
  - Translator (12 languages)
  - MCP Tools Client
  - Chrome Extension Support
  - Split View (F11)
  - Dark/Light/System theme
  - Auto-update from GitHub

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+T` | New Tab |
| `Ctrl+W` | Close Tab |
| `Ctrl+L` | Focus Address Bar |
| `Ctrl+H` | History |
| `Ctrl+B` | Add Bookmark |
| `Ctrl+D` | Downloads |
| `Ctrl+P` | Settings |
| `F5` | Refresh |
| `F11` | Split View |

## Build

### Windows
```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . --config Release
```

### Linux (requires webkit2gtk)
```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make
```

## Auto-Update

Automatically checks `https://github.com/TOREofficial/FewMB` for new releases on startup.

## Project Structure

```
FewMB-Browser/
├── src/
│   └── browser.cpp     # All code in single file (~1000 lines)
├── .github/workflows/
└── CMakeLists.txt
```

## Requirements

- Windows 10+ with WebView2 Runtime (pre-installed on Windows 11)
- ~100MB disk space
- ~50MB RAM minimum

## License

MIT License